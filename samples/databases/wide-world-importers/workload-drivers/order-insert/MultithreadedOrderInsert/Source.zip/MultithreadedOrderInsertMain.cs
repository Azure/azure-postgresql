﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
//using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using NpgsqlTypes;
using MultithreadedOrderInsert;

namespace MultithreadedInMemoryTableInsert
{
    public partial class MultithreadedOrderInsertMain : Form
    {
        public bool errorHasOccurred;
        public string errorDetails;
        public string dbVendorSelection;

        private DbVendorType dbVendorType;
        private Thread[] sqlTasks;
        private Int64 totalOrders;
        private Int64 totalMilliseconds;

        public MultithreadedOrderInsertMain()
        {
            InitializeComponent();
        }

        private void MultithreadedOrderInsertMain_Load(object sender, EventArgs e)
        {
            // populate db vendor combo box
            dbVendorComboBox.DataSource = Enum.GetValues(typeof(DbVendorType));

            ConnectionStringTextBox.Text = MultithreadedOrderInsert.Properties.Settings.Default.WWI_ConnectionString;
            if (ConnectionStringTextBox.Text.Length == 0)
            {
                ConnectionStringTextBox.Text = "Server=.;Database=WideWorldImporters;Integrated Security=true;Column Encryption Setting=disabled;Max Pool Size=250;";
            }
        }

        private void MultithreadedOrderInsertMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            MultithreadedOrderInsert.Properties.Settings.Default.WWI_ConnectionString = ConnectionStringTextBox.Text;
            MultithreadedOrderInsert.Properties.Settings.Default.Save();
        }

        public void UpdateTotals(int MillisecondsForOrder)
        {
            lock (this)
            {
                this.totalOrders += 1;
                this.totalMilliseconds += MillisecondsForOrder;
            }
        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            if (InsertButton.Text == "&Insert")
            {
                InsertButton.Text = "&Stop Now";
                InsertButton.Refresh();
                this.Refresh();

                DisplayUpdateTimer.Enabled = true;

                this.errorHasOccurred = false;
                this.errorDetails = "";

                this.totalOrders = 0;
                this.totalMilliseconds = 0;

                this.dbVendorSelection = this.dbVendorComboBox.SelectedValue.ToString();
                Enum.TryParse<DbVendorType>(this.dbVendorSelection, out dbVendorType);

                if (ConnectionStringTextBox.Text.Length == 0)
                {
                    ConnectionStringTextBox.Text = "Server=.;Database=WideWorldImporters;Integrated Security=true;Column Encryption Setting=disabled;Max Pool Size=250;";
                }

                if (!ConnectionStringTextBox.Text.ToUpper().Contains("MAX POOL SIZE") && dbVendorSelection != DbVendorType.PostgreSql.ToString())
                {
                    ConnectionStringTextBox.Text = (ConnectionStringTextBox.Text + ";Max Pool Size=250;").Replace(";;", ";");
                }

                try
                {
                    int numberOfThreads = (int)NumberOfThreadsNumericUpDown.Value;

                    sqlTasks = new Thread[numberOfThreads];

                    for (int threadCounter = 0; threadCounter < numberOfThreads; threadCounter++)
                    {
                        PerformSqlTask(threadCounter, this);
                    }

                }
                catch (Exception ex)
                {
                    this.errorHasOccurred = true;
                    this.errorDetails = ex.ToString();
                }

                if (this.errorHasOccurred)
                {
                    var errorForm = new ErrorDetailsForm();
                    errorForm.ErrorMessage = this.errorDetails;
                    errorForm.ShowDialog();
                }
            }
            else
            {
                InsertButton.Text = "Stopping";
                InsertButton.Refresh();
                this.Refresh();

                DisplayUpdateTimer.Enabled = false;

                if (sqlTasks != null)
                {
                    foreach (Thread thread in sqlTasks)
                    {
                        thread.Abort();
                    }
                }

                InsertButton.Text = "&Insert";
            }
        }

        public void PerformSqlTask(int TaskNumber, MultithreadedOrderInsertMain ParentForm)
        {
            //MessageBox.Show(dbVendorType.ToString());

            switch (dbVendorType)
            {
                case DbVendorType.MsSqlServer:
                    sqlTasks[TaskNumber] = new System.Threading.Thread(() => new MsSqlTask(TaskNumber, ParentForm, ConnectionStringTextBox.Text).PerformSqlTask());
                    sqlTasks[TaskNumber].Start();
                    break;
                case DbVendorType.PostgreSql:
                    sqlTasks[TaskNumber] = new System.Threading.Thread(() => new PostgreSqlTask(TaskNumber, ParentForm, ConnectionStringTextBox.Text).PerformSqlTask());
                    sqlTasks[TaskNumber].Start();
                    break;
                default:
                    break;
            }
        }

        private void DisplayUpdateTimer_Tick(object sender, EventArgs e)
        {
            if (this.totalOrders > 0)
            {
                AverageOrderInsertionTimeTextBox.Text = (totalMilliseconds / totalOrders).ToString();
                AverageOrderInsertionTimeTextBox.Refresh();
                this.Refresh();
            }
        }

        enum DbVendorType
        {
            MsSqlServer,
            PostgreSql
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using MultithreadedInMemoryTableInsert;

namespace MultithreadedOrderInsert
{
    class MsSqlTask : SqlTasks
    {
        public MsSqlTask(int TaskNumber, MultithreadedOrderInsertMain ParentForm, string ConnectionString)
            : base(TaskNumber, ParentForm, ConnectionString)
        {

        }

        public override void PerformSqlTask()
        {
            var errorOccurred = false;

            while (!errorOccurred)
            {
                try
                {
                    using (var con = new SqlConnection(_connectionstring))
                    {
                        var startingTime = DateTime.Now;

                        con.Open();

                        using (var selectCommand = con.CreateCommand())
                        {
                            var da = new SqlDataAdapter(selectCommand);
                            var rnd = new Random(_tasknumber);

                            selectCommand.CommandText = "SELECT TOP(1) PersonID FROM [Application].People WHERE IsEmployee <> 0 ORDER BY NEWID();";
                            var personTable = new DataTable("Person");
                            da.Fill(personTable);

                            var salespersonID = (int)(personTable.Rows[0]["PersonID"]);

                            selectCommand.CommandText = "SELECT TOP(1) 1 AS OrderReference, c.CustomerID, c.PrimaryContactPersonID AS ContactPersonID, CAST(DATEADD(day, 1, SYSDATETIME()) AS date) AS ExpectedDeliveryDate, CAST(FLOOR(RAND() * 10000) + 1 AS nvarchar(20)) AS CustomerPurchaseOrderNumber, CAST(0 AS bit) AS IsUndersupplyBackordered, N'Auto-generated' AS Comments, c.DeliveryAddressLine1 + N', ' + c.DeliveryAddressLine2 AS DeliveryInstructions FROM Sales.Customers AS c ORDER BY NEWID();";
                            var orderTable = new DataTable("Orders");
                            da.Fill(orderTable);

                            selectCommand.CommandText = "SELECT TOP(7) 1 AS OrderReference, si.StockItemID, si.StockItemName AS [Description], FLOOR(RAND() * 10) + 1 AS Quantity FROM Warehouse.StockItems AS si WHERE IsChillerStock = 0 ORDER BY NEWID()";
                            if (rnd.Next(1, 100) < 4)
                            {
                                selectCommand.CommandText += "UNION ALL SELECT TOP(1) 1 AS OrderReference, si.StockItemID, si.StockItemName AS [Description], FLOOR(RAND() * 10) + 1 AS Quantity FROM Warehouse.StockItems AS si WHERE IsChillerStock <> 0 ORDER BY NEWID()";
                            }
                            selectCommand.CommandText += ";";
                            var orderLinesTable = new DataTable("OrderLines");
                            da.Fill(orderLinesTable);

                            using (var insertCommand = con.CreateCommand())
                            {
                                insertCommand.CommandType = CommandType.StoredProcedure;
                                insertCommand.CommandText = "Website.InsertCustomerOrders";

                                var orderList = new SqlParameter("@Orders", SqlDbType.Structured);
                                orderList.TypeName = "Website.OrderList";
                                orderList.Value = orderTable;
                                insertCommand.Parameters.Add(orderList);

                                var orderLineList = new SqlParameter("@OrderLines", SqlDbType.Structured);
                                orderLineList.TypeName = "Website.OrderLineList";
                                orderLineList.Value = orderLinesTable;
                                insertCommand.Parameters.Add(orderLineList);

                                var ordersCreatedByPersonID = new SqlParameter("@OrdersCreatedByPersonID", SqlDbType.Int);
                                ordersCreatedByPersonID.Value = salespersonID;
                                insertCommand.Parameters.Add(ordersCreatedByPersonID);

                                var salespersonPersonID = new SqlParameter("@SalespersonPersonID", SqlDbType.Int);
                                salespersonPersonID.Value = salespersonID;
                                insertCommand.Parameters.Add(salespersonPersonID);

                                insertCommand.ExecuteNonQuery();
                            }
                        }
                        con.Close();

                        _parentform.UpdateTotals((int)DateTime.Now.Subtract(startingTime).TotalMilliseconds);
                    }
                }
                catch (Exception ex)
                {
                    errorOccurred = true;
                    _parentform.errorHasOccurred = true;
                    _parentform.errorDetails = ex.ToString();
                    //throw;
                }

                if (_parentform.errorHasOccurred)
                {
                    var errorForm = new ErrorDetailsForm();
                    errorForm.ErrorMessage = _parentform.errorDetails;
                    errorForm.ShowDialog();
                }
            }
        }
    }
}

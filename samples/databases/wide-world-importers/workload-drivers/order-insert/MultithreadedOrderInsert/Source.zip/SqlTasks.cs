﻿using MultithreadedInMemoryTableInsert;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultithreadedOrderInsert
{
    abstract class SqlTasks
    {
        public static int _tasknumber { get; set; }

        public static MultithreadedOrderInsertMain _parentform { get; set; }

        public static string _connectionstring { get; set; }

        public SqlTasks(int TaskNumber, MultithreadedOrderInsertMain ParentForm, string ConnectionString)
        {
            _tasknumber = TaskNumber;
            _parentform = ParentForm;
            _connectionstring = ConnectionString;
        }

        public abstract void PerformSqlTask();
    }
}

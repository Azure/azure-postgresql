﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using Npgsql;
//using NpgsqlTypes;

//namespace MultithreadedOrderInsert
//{
//    class PostgresSqlTaskDap
//    {
//        public void TestFunction()
//        {
//            using (var cmd = new NpgsqlCommand("INSERT INTO some_table (some_enum, some_type) VALUES (@p1, @p2)", Conn))
//            {
//                cmd.Parameters.AddWithValue("p1", new OrderList);
//                cmd.Parameters.AddWithValue("p2", new SomeType { ... });
//                cmd.ExecuteNonQuery();
//            }

//        }

//        public class PersonTableTypes
//        {
//            public int person_id;
//        }

//        public class OrderList
//        {
//            public int order_reference;
//            public int customer_id;
//            public int contact_person_id;
//            public NpgsqlDate expected_delivery_date;
//            public string customer_purchase_order_number;
//            public bool is_undersupply_backordered;
//            public string comments;
//            public string delivery_instructions;
//        }

//        public class OrderLineList
//        {
//            public int order_reference;
//            public int stock_item_id;
//            public string description;
//            public int quantity;
//        }

//    }
//}
